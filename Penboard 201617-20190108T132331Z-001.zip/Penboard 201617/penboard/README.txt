How to Run
- DOWNLOAD METEOR
- Make sure you have node.js running on the system, if you don't download it
- Open command prompt
- Change the directory to the folders that has the code
- Run the code by typing: meteor
- Go to the local host and see the site