How to Run
- Make sure you have node.js running on the system, if you don't download it
- Open command prompt
- Change the directory to the folders that has the code
- Run the code by typing: node main.js
- Go to the local host and see the site localhost:9098