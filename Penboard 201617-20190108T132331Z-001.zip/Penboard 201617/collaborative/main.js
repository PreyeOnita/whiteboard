//making an express applicatyion so it can be triggered
//in a variable called app aka IMPORTING THE EXPRESS MODULE
var express = require('express');
var app = express();
var server = app.listen(9098);
//telling the server to host the files in public
app.use(express.static('public'));
console.log("yasss b! server running");
var socket = require('socket.io');
//io is going to keep track of incoming and outgoing messages 
var io = socket(server);
//if you have a new connection(from the socket)
io.sockets.on('connection', newConnection);
function newConnection(socket){
	//every new connection to the server gets assigned an id automatically
	console.log(socket.id);
	
	socket.on('mouse', messagefromouse);
	
	function messagefromouse(boardata){
		//data goes to everyone connected
		socket.broadcast.emit('mouse', boardata);
		console.log(boardata);
	}
}